El proyecto se empieza a leer en el ProyectoFinal.html

Para el link Tableau fue enviada una envitación al correo: lzuniga@itcr.ac.cr debido a que los datos son sensibles, y no se pueden publicar al publico en general.

https://prod-useast-a.online.tableau.com/#/site/publicdata/workbooks/111731/views

